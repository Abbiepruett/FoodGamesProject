import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.Desktop;
import java.net.URI;

import java.awt.Insets;
import java.awt.Color;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;

/**
 * Sabrina Hasik
 * UIN: 231000384
 * Date: April, 2024
 * Final Project, Sabrina's Fantasy Foods Button
 * fantasyFrame()
 */
public class fantasyFrame extends JPanel implements ActionListener{

    //Initialize all variables, comboBoxes, Labels, etc.
    private JComboBox <String> comboBox1;
    private JComboBox  <String> comboBox2;
    private JComboBox  <String> comboBox3;
    private JComboBox  <String> comboBox4;
    private JComboBox  <String> comboBox5;
    private JComboBox  <String> comboBox6;
    private JComboBox  <String> comboBox7;
    private JComboBox  <String> comboBox8;
    private JComboBox  <String> comboBox9;
    private JComboBox  <String> comboBox10;

    private JLabel comboBoxLabel1;
    private JLabel comboBoxLabel2;
    private JLabel comboBoxLabel3;
    private JLabel comboBoxLabel4;
    private JLabel comboBoxLabel5;
    private JLabel comboBoxLabel6;
    private JLabel comboBoxLabel7;
    private JLabel comboBoxLabel8;
    private JLabel comboBoxLabel9;
    private JLabel comboBoxLabel10;

    private JLabel instructions1;
    private JLabel instructions2;

    private JTextField resultField;
    private JButton resultButton;

    private JButton movieButton;


    // private JFrame newFrame;
    // private JLabel background;

    // private ImageIcon image1;

    //Initialize video link
    String link = "";

    public fantasyFrame() {

        //Trying to Add a Background Image
        // JLabel background;
        // JPanel contentPane = new JPanel(null);
        // ImageIcon image1 = new ImageIcon("miyazaki4.gif");
        // background = new JLabel("", image1, JLabel.CENTER);
        // background.setSize(900, 500);
        // background.setBounds(0, 0, 900, 500);
        
        // contentPane.setVisible(true);

        //add(contentPane);

        //fantasyFrame.setLocationRelativeTo(null);
        GridBagConstraints positionConst = null;

        // newFrame = new JFrame("Fantasy Foods");
        // ImageIcon background = new ImageIcon("miyazaki4.gif");
        // Image img = background.getImage();

        // background = new JLabel("", image1, JLabel.CENTER);
        // background.setSize(900, 500);
        // background.setBounds(0, 0, 900, 500);
        // contentPane.add(background);
        // appFrame.setContentPane(contentPane);           
        // // JLabel background;
        // JPanel contentPane = new JPanel(null);
        // ImageIcon image1 = new ImageIcon("miyazaki4.gif");
        // background = new JLabel("", image1, JLabel.CENTER);
        // background.setSize(900, 500);
        // background.setBounds(0, 0, 900, 500);

        // fantasyFrame.setContentPane(contentPane);
        // fantasyFrame.getContentPane().add(background);

        //Result Field and Button
        resultButton = new JButton("Calculate my Result");
        resultButton.addActionListener(this);
        resultField = new JTextField(25);

        //Movie Button
        movieButton = new JButton("Show me this Fantasy Film");
        movieButton.addActionListener(this);

        //Add User Instructions
        instructions1 = new JLabel("Welcome to The Fantasy Food Calculator");
        instructions2 = new JLabel("Select 10 foods, and we'll recommend a fantasy world based on your choices!");

        //ComboBox Food Choices
        String[] breakfastChoice = {"Eggs, Sausage, and Muffins with Jam", "Waffles", "Marmalade Toast", "Nausage"};
        String[] breadChoice = {"Elvish Lembas", "Suli Skillet Bread", "Crumpets and Teacakes", "Rey's Portion Bread"};
        String[] drinkChoice1 = {"Miruvor Wine", "Ravkan Kvas", "Butterbeer", "Jawa Juice"};
        String[] drinkChoice2 = {"Mead", "Kerch Coffee", "Pumpkin Juice", "Blue Milk"};
        String[] appetizerChoice1 = {"Seed Bread", "Chocolate Biscuits", "Chocolate Frogs", "Paddy Frogs"};
        String[] appetizerChoice2 = {"Sauteed Mushrooms", "Honey Roasted Quail", "Cornish Pasties", "Deep Fried Nuna Legs"};
        String[] meatChoice = {"Salted Pork", "Reindeer Jerky", "Halloween Tripe", "Roasted Porg"};
        String[] seafoodChoice = {"Raw Wild-Caught Fish", "Smoked Cod", "Bouillabaisse", "Ach-To Fish"};
        String[] mainDishChoice = {"Shepherd's Pie", "Venison Steak", "Steak and Kidney pie", "Yoda's Stew"};
        String[] desertChoice = {"Honey Cakes", "Rosewater Pudding", "Fizzing Whizbees", "Meiloorun Fruit"};

        //ComboBox Food Labels
        comboBoxLabel1 = new JLabel("Choose a Breakfast:");
        comboBoxLabel2 = new JLabel("Choose a Bread:");
        comboBoxLabel3 = new JLabel("Choose a Drink:");
        comboBoxLabel4 = new JLabel("Choose another Drink:");
        comboBoxLabel5 = new JLabel("Choose an Appetizer:");
        comboBoxLabel6 = new JLabel("Choose another Appetizer:");
        comboBoxLabel7 = new JLabel("Choose a Protein:");
        comboBoxLabel8 = new JLabel("Choose a Seafood Dish:");
        comboBoxLabel9 = new JLabel("Choose a Main Dish:");
        comboBoxLabel10 = new JLabel("Choose a Desert:");

        //Add each element using GridBag Constraints
        comboBox1 = new JComboBox<>(breakfastChoice);
        comboBox1.setSelectedIndex(0);
        comboBox1.addActionListener(this);

        comboBox2 = new JComboBox<>(breadChoice);
        comboBox2.setSelectedIndex(0);
        comboBox2.addActionListener(this);

        comboBox3 = new JComboBox<>(drinkChoice1);
        comboBox3.setSelectedIndex(0);
        comboBox3.addActionListener(this);

        comboBox4 = new JComboBox<>(drinkChoice2);
        comboBox4.setSelectedIndex(0);
        comboBox4.addActionListener(this);

        comboBox5 = new JComboBox<>(appetizerChoice1);
        comboBox5.setSelectedIndex(0);
        comboBox5.addActionListener(this);

        comboBox6 = new JComboBox<>(appetizerChoice2);
        comboBox6.setSelectedIndex(0);
        comboBox6.addActionListener(this);

        comboBox7 = new JComboBox<>(meatChoice);
        comboBox7.setSelectedIndex(0);
        comboBox7.addActionListener(this);

        comboBox8 = new JComboBox<>(seafoodChoice);
        comboBox8.setSelectedIndex(0);
        comboBox8.addActionListener(this);

        comboBox9 = new JComboBox<>(mainDishChoice);
        comboBox9.setSelectedIndex(0);
        comboBox9.addActionListener(this);

        comboBox10 = new JComboBox<>(desertChoice);
        comboBox10.setSelectedIndex(0);
        comboBox10.addActionListener(this);

        setLayout(new GridBagLayout());
        positionConst = new GridBagConstraints();

        //contentPane.add(background);
        //add(contentPane);

        //Add Result Field and Button
        positionConst.gridx = 0;
        positionConst.gridy = 0;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(resultButton, positionConst);

        positionConst.gridx = 1;
        positionConst.gridy = 0;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(resultField, positionConst);

        //Add Instruction Labels
        positionConst.gridx = 1;
        positionConst.gridy = 1;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(instructions1, positionConst);

        positionConst.gridx = 1;
        positionConst.gridy = 2;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(instructions2, positionConst);

        //Add ComboBox Labels
        positionConst.gridx = 0;
        positionConst.gridy = 3;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel1, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 4;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel2, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 5;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel3, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 6;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel4, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 7;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel5, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 8;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel6, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 9;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel7, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 10;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel8, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 11;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel9, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 12;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBoxLabel10, positionConst);

        //Add ComboBoxes Here!!
        positionConst.gridx = 2;
        positionConst.gridy = 3;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox1, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 4;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox2, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 5;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox3, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 6;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox4, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 7;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox5, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 8;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox6, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 9;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox7, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 10;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox8, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 11;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox9, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 12;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(comboBox10, positionConst);  
        
        positionConst.gridx = 0;
        positionConst.gridy = 13;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(movieButton, positionConst);  
        
    }

    @Override
    public void actionPerformed(ActionEvent event){
        
        //Result Button displays user's calculated fantasy world 
        if (event.getSource() == resultButton) {
            //Take in comboBox input as objects, convert to strings.
            Object comboObject1 = comboBox1.getSelectedItem();
            Object comboObject2 = comboBox2.getSelectedItem();
            Object comboObject3 = comboBox3.getSelectedItem();
            Object comboObject4 = comboBox4.getSelectedItem();
            Object comboObject5 = comboBox5.getSelectedItem();
            Object comboObject6 = comboBox6.getSelectedItem();
            Object comboObject7 = comboBox7.getSelectedItem();
            Object comboObject8 = comboBox8.getSelectedItem();
            Object comboObject9 = comboBox9.getSelectedItem();
            Object comboObject10 = comboBox10.getSelectedItem();

            String comboString1 = comboObject1.toString();
            String comboString2 = comboObject2.toString();
            String comboString3 = comboObject3.toString();
            String comboString4 = comboObject4.toString();
            String comboString5 = comboObject5.toString();
            String comboString6 = comboObject6.toString();
            String comboString7 = comboObject7.toString();
            String comboString8 = comboObject8.toString();
            String comboString9 = comboObject9.toString();
            String comboString10 = comboObject10.toString();

            //CALCULATE RESULT HERE 
            String[] choices = {comboString1, comboString2, comboString3, comboString4, comboString5, comboString6, comboString7, comboString8, comboString9, comboString10};
            for (int i = 0; i < choices.length; i++) {
                choices[i] = convertToLetter(choices[i]);
                //Use convertToLetter method to convert each input into their associated fantasy world. 
            }
            String myWorld = count(choices);
            //System.out.println(myWorld);
            resultField.setText(myWorld);
            
            //Depending on the resulting "world" the link is assigned appropriately
            if (myWorld.equals("Harry Potter: The Wizarding World")) {
                link = "https://www.youtube.com/watch?v=5hU0EeBQEZY";
            }
            else if (myWorld.equals("Star Wars: A Galaxy Far, Far Away.")) {
                link = "https://www.youtube.com/watch?v=sGbxmsDFVnE";
            }
            else if (myWorld.equals("Shadow and Bone: The Grishaverse")) {
                link = "https://www.youtube.com/watch?v=b1WHQTbJ7vE";
            }
            else if (myWorld.equals("Lord of the Rings: Middle Earth")) {
                link = "https://www.youtube.com/watch?v=x8UAUAuKNcU";
            }
            //Maura helped me with this!! :))           
        }

        if (event.getSource() == movieButton) {
            //This button displays a movie trailer from the user's chosen fantasy world
            final String linkFinal = link;
            new Thread(() -> {
                try {
                    URI uri = new URI(linkFinal);
                    Desktop.getDesktop().browse(uri);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }).start();
        } 
    }

    private String count(String[] countArray) {
        //This method counts the instances of each food choice WRT to the corresponding fantasy world
        //In others words, it takes in the array of letters that each correspong to different worlds,
        //And finds the most frequently chosen world. 
        String result = "N/A";
        int lotrCount = 0;
        int grishaCount = 0;
        int harryCount = 0;
        int starCount = 0;
        for (int i = 0; i < countArray.length; i++) {
            if (countArray[i].equals("L")) {
                lotrCount++;
            }
            else if (countArray[i].equals("G")) {
                grishaCount++;
            }
            else if (countArray[i].equals("H")) {
                harryCount++;
            }
            else if (countArray[i].equals("S")) {
                starCount++;
            }
        }
        int[] maxArray = {starCount, lotrCount, grishaCount, harryCount};
        // The order here in maxArray is intentional!
        //Rather than deal with ties between two choices, I ordered these backwards by my personal favorites
        //The for loop goes through backwards with a >= comparison, so if there are an equal number of Star 
        //Wars and Harry Grishaverse food choices, the result the user will get is the Grishaverse!
        //I borrowed this idea from Buzzfeed Quizzes, because they work in a similar way.
        int maxVal = 0;
        int maxIndex = 0;
        for (int i = 0; i < maxArray.length; i++) {
            if (maxArray[i] >= maxVal) {
                maxVal = maxArray[i];
                maxIndex = i;
            }
        }
        if (maxIndex == 3) {
            result = "Harry Potter: The Wizarding World";
        }
        else if (maxIndex == 2) {
            result = "Shadow and Bone: The Grishaverse";
        }
        else if (maxIndex == 1) {
            result = "Lord of the Rings: Middle Earth";
        }
        else if (maxIndex == 0) {
            result = "Star Wars: A Galaxy Far, Far Away.";
        }
        return result;
    }

    private String convertToLetter(String comboString) {
        //This method converts a food choice into the corresponding fantasy world
        // L, G, H, and S represent Lord of the Rings, the Grishaverse, Harry Potter, and Star Wars, respectively.
        String result = "000";
        if (comboString.equals("Eggs, Sausage, and Muffins with Jam") || comboString.equals("Elvish Lembas") || comboString.equals("Miruvor Wine") || comboString.equals("Mead")
         || comboString.equals("Seed Bread") || comboString.equals("Salted Pork") || comboString.equals("Sauteed Mushrooms") || comboString.equals("Raw Wild-Caught Fish") || 
         comboString.equals("Shepherd's Pie") | comboString.equals("Honey Cakes")) {
            result = "L";
        } 
        else if (comboString.equals("Waffles") || comboString.equals("Suli Skillet Bread") || comboString.equals("Ravkan Kvas") || comboString.equals("Kerch Coffee")
        || comboString.equals("Chocolate Biscuits") || comboString.equals("Honey Roasted Quail") || comboString.equals("Reindeer Jerky") || comboString.equals("Smoked Cod") || 
        comboString.equals("Venison Steak") | comboString.equals("Rosewater Pudding")) {
            result = "G";
        }
        else if (comboString.equals("Marmalade Toast") || comboString.equals("Crumpets and Teacakes") || comboString.equals("Butterbeer") || comboString.equals("Pumpkin Juice")
        || comboString.equals("Chocolate Frogs") || comboString.equals("Cornish Pasties") ||comboString.equals("Halloween Tripe") || comboString.equals("Bouillabaisse") || 
        comboString.equals("Steak and Kidney pie") || comboString.equals("Fizzing Whizbees") ) {
            result = "H";
        }
        else if (comboString.equals("Nausage") || comboString.equals("Rey's Portion Bread") || comboString.equals("Jawa Juice") || comboString.equals("Blue Milk")
        || comboString.equals("Paddy Frogs") || comboString.equals("Deep Fried Nuna Legs") || comboString.equals("Roasted Porg") || comboString.equals("Ach-To Fish") || 
        comboString.equals("Yoda's Stew") | comboString.equals("Meiloorun Fruit")) {
            result = "S";
        }
        return result;
    }
}