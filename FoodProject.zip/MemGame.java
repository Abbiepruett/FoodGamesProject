/**
 * Taylor Kanzleiter
 * CSCE Final - Memory Game
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;

public class MemGame extends JFrame {

    // Declare variables
    JTextField inputField;
    JButton submitButton;
    ArrayList<String> orders;
    ArrayList<String> names;
    int currentLevel;

    // Create Panel
    public MemGame() {
        setTitle("Aggie Cafe");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 300);
        setLocationRelativeTo(null);
        setContentPane(new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(240, 218, 163));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        });

        // Create Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        // Create Input Panel
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(60, 100, 60, 100));
        inputField = new JTextField();
        inputField.setPreferredSize(new Dimension(300, 50));
        inputPanel.add(inputField, BorderLayout.CENTER);

        // Create Input Button
        submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
            }
        });
        mainPanel.add(inputPanel, BorderLayout.CENTER);
        mainPanel.add(submitButton, BorderLayout.SOUTH);

        add(mainPanel);

        orders = new ArrayList<>();
        names = new ArrayList<>();
        currentLevel = 1;

        displayWelcomeMessage();

        setVisible(true);
    }

    // Display Welcome Message to Player
    public void displayWelcomeMessage() {
        String message = "Welcome to the Aggie Cafe!\n\n" +
                "Here's how to play:\n" +
                "1. You will be shown orders of increasing difficulty. Memorize and repeat them to pass the level. \n" +
                "2. If you get the order correct, you move on. If you are incorrect, you go back to Level 1.\n" +
                "3. Complete all three levels to finish the game.\n\n" +
                "Let's get started!";
        JOptionPane.showMessageDialog(this, message, "Welcome", JOptionPane.INFORMATION_MESSAGE);
    }

    // Generate Random Order
    public String generateOrder(int level) {
        ArrayList<String> menu = new ArrayList<>(Arrays.asList("Pizza", "Burger", "Sushi", "Tacos", "Pasta", "Salad", "Steak", "Soup", "Sandwich", "Curry"));

        Random random = new Random();

        StringBuilder stringBuilder = new StringBuilder();

        int numItems;

        switch (level) {
            case 1:
                numItems = 3;
                break;
            case 2:
                numItems = 4;
                break;
            case 3:
                numItems = 5;
                break;
            default:
                numItems = 0;
        }

        for (int i = 0; i < numItems; i++) {
            int randomIndex = random.nextInt(menu.size());
            String orderItem = menu.get(randomIndex);
            stringBuilder.append(orderItem);
            if (i < numItems - 1) {
                stringBuilder.append(", ");
            }
            menu.remove(randomIndex);
        }

        String order = stringBuilder.toString();

        orders.add(order);

        String name = names.get(level - 1);

        return name + "'s Order: " + order;
    }

    // Generate Names For Order
    public void generateNames() {
        String[] allNames = {"Alice", "Bob", "Charlie", "David", "Emma", "Frank", "Grace", "Henry", "Ivy", "Jack"};
        names.clear();
        names.addAll(Arrays.asList(allNames));
        Collections.shuffle(names);
    }

    // Generate A New Order
    public void generateOrder() {

        if (currentLevel == 1) {
            orders.clear();
        }

        generateNames();

        String order = generateOrder(currentLevel);

        JOptionPane.showMessageDialog(this, order, "Level " + currentLevel, JOptionPane.INFORMATION_MESSAGE);

        inputField.setText("");
    }

    // Check if User Input is Correct
    public void checkAnswer() {
        String userInput = inputField.getText().trim();

        String correctOrder = orders.get(currentLevel - 1);

        if (userInput.equalsIgnoreCase(correctOrder)) {
            JOptionPane.showMessageDialog(this, "That's correct!");
            currentLevel++;
            if (currentLevel <= 3) {
                int choice = JOptionPane.showConfirmDialog(this, "Would you like to play the next level?", "Level " + currentLevel, JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    generateOrder();
                } else {
                    JOptionPane.showMessageDialog(this, "Thanks for playing!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                    dispose(); // Close the window and end the game
                }
            } else {
                int choice = JOptionPane.showConfirmDialog(this, "Congratulations! You finished! Would you like to play again?", "Game Over", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    currentLevel = 1;
                    generateOrder();
                } else {
                    JOptionPane.showMessageDialog(this, "Thanks for playing!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                    dispose();
                }
            }
        } else { // If incorrect, reset to level 1
            JOptionPane.showMessageDialog(this, "Oops! That's not quite right...");
            currentLevel = 1;
            generateOrder();
        }
        inputField.setText("");
    }
}