import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.net.URI;

/**
 * Maura Flanagan
 * 529009459
 * Group Project, Maura's Button
 * dinnerIdeas
 */


public class dinnerIdeas extends JPanel implements ActionListener{

    private JLabel proteinLabel;
    private JLabel veggieLabel;
    private JLabel fillerLabel;
    private JLabel difficultyLabel;
    private JComboBox<String> protein;
    private JComboBox<String> veggie;
    private JComboBox<String> filler;
    private JComboBox<String> difficulty;
    private JButton calcButton;

    public dinnerIdeas(){
        GridBagConstraints positionConst = null;

        String[] proteinChoices = new String[]{"None","Chicken","Beef"};
        String[] veggieChoices = new String[]{"Broccoli","Fajita Veggies","Neither"};
        String[] fillerChoices = new String[]{"Quinoa","Rice","Pasta"};
        String[] difficultyChoices = new String[]{"Easy","Difficult"};


        protein = new JComboBox<>(proteinChoices);
        veggie = new JComboBox<>(veggieChoices);
        filler = new JComboBox<>(fillerChoices);
        difficulty = new JComboBox<>(difficultyChoices);

        proteinLabel = new JLabel("Protein:");
        veggieLabel = new JLabel("Vegetable:");
        fillerLabel = new JLabel("Filler:");
        difficultyLabel = new JLabel("Difficulty:");


        calcButton = new JButton("Find Recipe");
        calcButton.addActionListener(this);

        setLayout(new GridBagLayout());
        positionConst = new GridBagConstraints();

        positionConst.gridx = 0;
        positionConst.gridy = 0;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(proteinLabel, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 0;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(protein, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 2;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(veggieLabel, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 2;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(veggie, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 4;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(fillerLabel, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 4;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(filler, positionConst);

        positionConst.gridx = 0;
        positionConst.gridy = 6;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(difficultyLabel, positionConst);

        positionConst.gridx = 2;
        positionConst.gridy = 6;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(difficulty, positionConst);

        positionConst.gridx = 1;
        positionConst.gridy = 8;
        positionConst.insets = new Insets(10, 10, 10, 10);
        add(calcButton, positionConst);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == calcButton) {
            Object proteinChoiceObj = protein.getSelectedItem();
            Object veggieChoiceObj = veggie.getSelectedItem();
            Object fillerChoiceObj = filler.getSelectedItem();
            Object difficultyChoiceObj = difficulty.getSelectedItem();
    
            String proteinChoice = proteinChoiceObj.toString();
            String veggieChoice = veggieChoiceObj.toString();
            String fillerChoice = fillerChoiceObj.toString();
            String difficultyChoice = difficultyChoiceObj.toString();
    
            // Generate recipe based on choices
            String link = generateRecipe(proteinChoice, veggieChoice, fillerChoice, difficultyChoice);
            // Open the link in a separate thread
            new Thread(() -> {
                try {
                    URI uri = new URI(link);
                    Desktop.getDesktop().browse(uri);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }).start();
        }
    }
    private String generateRecipe(String proteinChoice, String veggieChoice, String fillerChoice, String difficultyChoice) {
        String link = "";
        if (veggieChoice.equals("Fajita Veggies")){
            if (proteinChoice.equals("Chicken")){
                link = "https://natashaskitchen.com/chicken-fajitas-recipe/";
            }
            else if (proteinChoice.equals("Beef")){
                link = "https://www.recipetineats.com/beef-fajitas/";
            } else{
                link = "https://www.twopeasandtheirpod.com/vegetarian-fajitas/";
            }
        }
        else if (veggieChoice.equals("Broccoli")){
            if (fillerChoice.equals("Rice")){
                if (proteinChoice.equals("Chicken")){
                    link = "https://cookinginthemidwest.com/blog/chickenbroccolirice/";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://www.saltandlavender.com/beef-and-broccoli/";
                } else{
                    link = "https://www.food.com/recipe/broccoli-and-rice-soup-402887";
                }

            } 
            else if (fillerChoice.equals("Quinoa")){
                if (proteinChoice.equals("Chicken")){
                    link = "https://pinchofyum.com/creamy-chicken-quinoa-broccoli-casserole";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://hh-hm.com/ground-beef-broccoli-fried-quinoa/";
                } else{
                    link = "https://www.wellplated.com/broccoli-quinoa-skillet/";
                }

            } else{
                if (proteinChoice.equals("Chicken")){
                    link = "https://www.kitchensanctuary.com/one-pot-chicken-broccoli-pasta/";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://www.budgetbytes.com/garlic-noodles-with-beef-and-broccoli/";
                } else{
                    link = "https://mangiawithmichele.com/italian-broccoli-pasta/";
                }
            }

        }
        else if (veggieChoice.equals("Neither")){
            if (fillerChoice.equals("Pasta")){
                if (proteinChoice.equals("Chicken")){
                    link = "https://thecozycook.com/creamy-chicken-pasta/";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://www.recipetineats.com/one-pot-creamy-tomato-beef-pasta/";
                } else{
                    link = "https://www.allrecipes.com/recipe/269500/creamy-garlic-pasta/";
                }
            }
            else if (fillerChoice.equals("Rice")){
                if (proteinChoice.equals("Chicken")){
                    link = "https://www.recipetineats.com/oven-baked-chicken-and-rice/";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://therecipecritic.com/korean-ground-beef-rice-bowls/";
                } else{
                    link = "https://chefsavvy.com/the-best-fried-rice/";
                }
            } else{
                if (proteinChoice.equals("Chicken")){
                    link = "https://feelgoodfoodie.net/recipe/chicken-quinoa-bowl/";
                }
                else if (proteinChoice.equals("Beef")){
                    link = "https://thebeachhousekitchen.com/beef-and-quinoa-enchilada-skillet/";
                } else{
                    link = "https://cookieandkate.com/best-quinoa-salad-recipe/";
                }
            }
        }
        return link;
    }
    
}