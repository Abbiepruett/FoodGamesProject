import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import java.awt.Desktop;
import java.net.URI;

import java.awt.Insets;
import java.awt.Color;
import java.awt.Font;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;

import javax.swing.JOptionPane;

import javax.swing.*;
import java.awt.*;

/**
 * Speed Team
 * April 8, 2024
 * guiFrame
 */
public class guiFrame8 {

    public static void main(String[] args) {

        
        //new frame
        JFrame appFrame = new JFrame();
    
        //set default location
        appFrame.setLocationRelativeTo(null);

        //set default size
        appFrame.setSize(900,500);

        //set operaton on exit
        appFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // program stops running when main frame is closed

        //set title 
        appFrame.setTitle("Main Food Frame.");

        //set background color
        //appFrame.getContentPane().setBackground(Color.MAGENTA);

        //create paenl to put buttons on
        JPanel contentPane = new JPanel(null);
        contentPane.setBackground(Color.GREEN);
        contentPane.setPreferredSize(new Dimension(900, 500)); //900 500
        contentPane.setOpaque(true);
        appFrame.setContentPane(contentPane);

        //set to middle of screen
        appFrame.setLocation(250,50); 
       

       //Title
        // Create JLabel to display text
        JLabel label = new JLabel("Fantastic Foods and Fun");
        label.setBounds(250, 50, 500, 30); // Set position and size of the label
        Font font = new Font ("Courier", Font.BOLD, 30);
        label.setFont(font); 
        label.setForeground(new Color(250, 142, 0)); 
        contentPane.add(label); // Add label to the panel


        //add buttons
        JButton button1 = new JButton("Maura's Button");
        JButton button2 = new JButton("Vivian's Button");
        JButton button3 = new JButton("Samantha's Button");
        JButton button4 = new JButton("Abbie's Button");
        JButton button5 = new JButton("Taylor's Button");
        JButton button6 = new JButton("Sabrina's Button");
        JButton button7 = new JButton("Video Button");

        //set position of buttons
        button1.setBounds(100, 150, 150, 50); 
        button2.setBounds(375, 150, 150, 50);
        button3.setBounds(650, 150, 150, 50);
        button4.setBounds(100, 250, 150, 50);
        button5.setBounds(375, 250, 150, 50);
        button6.setBounds(650, 250, 150, 50);
        button7.setBounds(375, 350, 150, 50);

        //add buttons to the panel

        //set background and foreground 
        button1.setBackground(new Color(149, 162, 189)); // Red color // Set background color
        button1.setForeground(Color.black); // Set text color
        button2.setBackground(new Color(149, 162, 189));
        button2.setForeground(Color.black);
        button3.setBackground(new Color(149, 162, 189));
        button3.setForeground(Color.black);
        button4.setBackground(new Color(149, 162, 189));
        button4.setForeground(Color.black); // Change text color to black for better visibility
        button5.setBackground(new Color(149, 162, 189));
        button5.setForeground(Color.black); // Change text color to black for better visibility
        button6.setBackground(new Color(149, 162, 189));
        button6.setForeground(Color.black); // Change text color to black for better visibility
        button7.setBackground(new Color(38, 38, 38));
        button7.setForeground(Color.black);
       
        //add buttons to the panel
        contentPane.add(button1);
        contentPane.add(button2);
        contentPane.add(button3);
        contentPane.add(button4);
        contentPane.add(button5);
        contentPane.add(button6);
        contentPane.add(button7);

        appFrame.setContentPane(contentPane);
        
        //make frame visible
        appFrame.setVisible(true);

        //Add Cute Miyazaki .gif to the background of main frame
        JLabel background;
        ImageIcon image1 = new ImageIcon("miyazaki4.gif");
        background = new JLabel("", image1,JLabel.CENTER);
        background.setSize(900,500);
        background.setBounds(0,0,900,500);
        contentPane.add(background);
        appFrame.setContentPane(contentPane);


        //open Maura's method when Maura's button is clicked
        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Instructions for button
                JOptionPane.showMessageDialog(null, "Instructions: \nPick which protein, vegetable, filler, and cooking difficulty \nOnce you have made your choices click Find recipe button. \nYou will be taken to a website that includes a recipe based on the specifications given by user.");

                // Open the DinnerIdeas frame
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JFrame dinnerFrame = new JFrame("Dinner Ideas");
                    dinnerFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); // program is still running when button1 frame is closed
                    dinnerFrame.getContentPane().add(new dinnerIdeas());
                    dinnerFrame.pack();
                    dinnerFrame.setVisible(true);

                });
            }
        });

        //add link to Vivian's button
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the Hangman2 class
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JFrame viviansButton = new JFrame("Hangman");
                    viviansButton.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE); // program is still running when button1 frame is closed
                    viviansButton.getContentPane().add(new Hangman2(viviansButton));
                    viviansButton.pack();
                    viviansButton.setVisible(true);
                    viviansButton.setLocation(500, 250);
                    //instructions
                    JOptionPane.showMessageDialog(null, "Instructions: \nUse your keyboard to guess letters. \nIf you get a letter correct it will appear in the correct spot. \nIf you guess a letter wrong it will appear at the top of the screen and a part of the hangman is drawn. \nThe game is over if you guess the word correctly or if the hangman is complete. \nGoodluck!");
                });
            }
        });


        //add link to Sam's button
        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //open Wordle frame
                samsButton game = new samsButton();
                game.WordleGame();
            }
        });

 
        //add link to Abbie's button
        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the bread quizframe
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JFrame abbiesButton = new JFrame("Abbie's Button");
                    abbiesButton.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                    abbiesButton.getContentPane().add(new BreadQuiz());
                    abbiesButton.pack();
                    abbiesButton.setVisible(true);
                });
            }
        });

         //add link to sabrina's button
        button6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Display insrtuctions
                JOptionPane.showMessageDialog(null, "Instructions: \nChoose ten foods from different fantasy worlds.\nGiven your choices, you will be assigned a fantasy world that most matches your taste in food.");
                JOptionPane.showMessageDialog(null,"Once you have been assigned a fantasy world, click the button \nat the bottom of the frame to get a sneak peek!");
                // Open the Fantasy Foods frame
                javax.swing.SwingUtilities.invokeLater(() -> {
                    JFrame fantasyFrame = new JFrame("Fantasy Foods");
                    fantasyFrame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                    fantasyFrame.getContentPane().add(new fantasyFrame());
                    fantasyFrame.pack();
                    fantasyFrame.setVisible(true);
                });
            }
        });
        

        // Add link to Taylor's Button
        button5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        MemGame game = new MemGame();
                        game.generateOrder();
                    }
                });
            }
        });


        button7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final String link7 = "https://www.youtube.com/watch?v=xVVHZ_CJllg";
                new Thread(() -> {
                try {
                    URI uri = new URI(link7);
                    Desktop.getDesktop().browse(uri);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }).start();
                
            }
        });


    }
    
}