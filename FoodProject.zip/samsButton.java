/*
 * Samantha White
 * UIN: 233009354
 * April 18, 2024
 * JFrame Project
 * Topic: Food
 * My Idea: Wordle-like Word Guesser
 * CSCE 111
 */

//swing imports used
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

//awt imports used
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.BorderLayout;
import java.awt.Color;

public class samsButton extends JFrame {
    String secretWord;
    JTextField guessField;
    JButton submitButton;
    JLabel resultLabel;
    JLabel instructions;
    JTextArea guessHistory;
    JPanel historyPanel;
    JLabel countLabel;
    //num of guesses you get
    int count = 5;
    //background color I'll use
    Color turquoise = new Color(108, 218, 231);

    public void WordleGame() {
        
        
        //title of frame
        setTitle("Sam's Wordle Game");
        //set size
        setSize(300, 400);
        //closes my frame, not the main frame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //center frame
        setLocationRelativeTo(null);
        //allow people to actually see the frame
        setVisible(true);
        //set background color :D
        getContentPane().setBackground(turquoise);

        //initialize and generate a random secret word
        secretWord = generateSecretWord();

        //initialize input field, submit button, and result label
        guessField = new JTextField(5);
        submitButton = new JButton("Submit");
        resultLabel = new JLabel("");
        countLabel = new JLabel("");

        //guess history configurations
        historyPanel = new JPanel(new BorderLayout());
        guessHistory = new JTextArea(5, 20); //5 rows, 20 columns
        guessHistory.setEditable(false); //don't want it to editable
        countLabel.setText("Guesses left: " + count);
        countLabel.setHorizontalAlignment(JLabel.CENTER);
        historyPanel.add(countLabel, BorderLayout.NORTH);
        historyPanel.add(new JLabel("Guess History:"), BorderLayout.NORTH);
        historyPanel.add(guessHistory, BorderLayout.CENTER);

        //set layout
        setLayout(new BorderLayout());
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Enter a 5-letter word:"));
        inputPanel.add(guessField);
        inputPanel.add(submitButton);

        //adjust where resultLabel is (actuall CENTER it)
        resultLabel.setHorizontalAlignment(JLabel.CENTER);
        resultLabel.setVerticalAlignment(JLabel.CENTER);

        //add components to frame
        add(inputPanel, BorderLayout.NORTH);
        add(resultLabel, BorderLayout.CENTER);
        add(historyPanel, BorderLayout.SOUTH);

        //add ActionListener to submitButton
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();

            }
        });

        //show welcome message & instructions
        JOptionPane.showMessageDialog(null, "Welcome to Sam's Food Wordle!\n\n Here are the instructions:\n"
                                        + "Each guess must be a valid five-letter word relating to food." 
                                        + "\nThe marker under the letter will change to show you how close your guess was."
                                        + "\nIf a O appears under the letter, the letter is in the word, and it is in the correct spot."
                                        + "\nIf an X appears under the letter, the letter is in the word, but it is not in the correct spot."
                                        + "\nIf a _ appears under the letter, the letter is not in the word."
                                        + "\nYou can choose to play again at the end of every solved word!");

    }

    //generate a random 5-letter food word
    public String generateSecretWord() {
        String[] words = {"apple", "ramen", "bread", "salad", "pasta", "pizza", "salsa", "olive", 
                          "chips", "onion", "fries", "bagel", "icing", "honey", "squid", "prune", "basil"};
        return words[(int) (Math.random() * words.length)];

    }

    //check the user's guess against secret word
    public void checkGuess() {
        String guess = guessField.getText().toLowerCase();
        if (guess.length() != 5) {
            resultLabel.setText("Please enter a 5-letter word.");
            return;

        }

        //after every attempt remove the amount of guesses they have left
        count--;
        countLabel.setText("Guesses left: " + count);

        //clear guessField
        guessField.setText("");

        //make sure they have enough attempts left
        if(count == 0){
            JOptionPane.showMessageDialog(this, "Oh no! You ran out of guesses!");
            //do they want to play again?
            int choice = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Play Again?", JOptionPane.YES_NO_OPTION);
            if(choice == JOptionPane.YES_OPTION){
                resetGame();

            }else{
                //if they choose not, close MY frame
                dispose();
            }

        }

        //check each letter of guess against secret word
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            char guessChar = guess.charAt(i);
            char secretChar = secretWord.charAt(i);

            //correct letter and position
            if (guessChar == secretChar) {
                result.append("O");

            //correct letter but wrong position
            } else if (secretWord.contains(String.valueOf(guessChar))) {
                result.append("X");

            //incorrect letter
            } else {
                result.append("_");
            }
        }

        //show result
        resultLabel.setText(result.toString());

        //append current guess & result to guess history text
        guessHistory.append(guess + "\n" + result.toString() + "\n");

        //check if guess is correct
        if (guess.equals(secretWord)) {
            JOptionPane.showMessageDialog(this, "Congratulations! You guessed the word: " + secretWord);
            //do they want to play again?
            int choice = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Play Again?", JOptionPane.YES_NO_OPTION);
            if(choice == JOptionPane.YES_OPTION){
                resetGame();

            }else{
                //if they choose not, close MY frame
                dispose();
            }
            

        }

        
    }

    //reset game
    public void resetGame() {
        //gets new secret word
        secretWord = generateSecretWord();
        //clears fields
        guessField.setText("");
        resultLabel.setText("");
        guessHistory.setText("");
        count = 5;
        countLabel.setText("Guesses left: " + count);

    }

    
}