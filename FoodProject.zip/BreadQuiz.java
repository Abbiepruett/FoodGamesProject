/*
 * Abbie Pruett
 * CSCE 111
 * Final Project
 */

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;




public class BreadQuiz extends JFrame implements ActionListener{
    String[] questionsArray;
    int correctAmt = 0;
    JComboBox comboBox;
    //int incorrectAmt = 0;

    //quiz questions
    String [][] myChoices = {{"A. Proofing","B. Folding","C. Scoring","D. Resting"},{"A. Sugar", "B. Vinegar", "C. Fermented starter", "D. Lemon Juice"},{"A. Baguette", "B. Focaccia", "C. Brioche", "D. Challah"}, 
    {"A. Rye flour","B. Whole wheat flour","C. Durum flour","D. white flour"},{"A. To add air into the dough","B. To develope gluten","C. To prevent the dough from rising too much","D. To distribute the yeast evenly"}, 
    {"A. Baking Powder","B. Yeast","C. Baking soda","D. Cream of tartar"},{"A. Kneading", "B. Scoring", "C. Proofing", "D. Folding"},{"A. Fermentation","B. Lamination","C. Enrichment","D. Infusion"}, {"A. Focaccia","B. Baguette","C. Ciabatta","D. Brioche"}, 
    {"A. Baguette","B. Challah","C. Pumpernickel","D. Sourdough"} };

    //correct answers
    String[] correct = {"A. Proofing","C. Fermented starter", "D. Challah", "D. white flour", "B. To develope gluten", "B. Yeast", "B. Scoring", "C. Enrichment", "A. Focaccia", "B. Challah"};
    
    public BreadQuiz()
    {   //create popup with instructons menu 
        JOptionPane.showMessageDialog(null, "Instructions: Select the answers to the corresponding questions from the dropdown menus and press submit when you are ready to see your score. Click the reset button to reset your score and the answer choices.\nClick the main menu button or the red X at the top to go back to the main menu.");

        
        //create gridBagConstraints 
        GridBagConstraints gbc = null; 
        setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);


        //create an array for all of my comboBoxes
        JComboBox[] comboBoxes = new JComboBox[10];

  
        //creates a new comboBox for each set of choices and appends to the array 
        for (int i = 0; i < 10; i++) {
            JComboBox comboBox = new JComboBox(myChoices[i]); // Assuming choicesArray is an array containing choices for each JComboBox
            comboBox.addActionListener(this);
            gbc.gridx = 1;
            gbc.gridy = i+1;
            add(comboBox, gbc);
            comboBoxes[i] = comboBox;

        }

       //set up submit button
       JButton submit = new JButton("Submit");
       gbc.gridx = 1;
       gbc.gridy = 11;
       add(submit,gbc);
       submit.addActionListener(this);

       //set up main menu button
       JButton menu = new JButton("Main Menu");
       gbc.gridx = 1;
       gbc.gridy = 12;
       add(menu,gbc);
       menu.addActionListener(this);

       //set up results display
        JTextField tfResult = new JTextField(15);
        tfResult.setEditable(false);
        gbc.gridx = 0;
        gbc.gridy = 11;
        add(tfResult,gbc);

       //set up results display
        JButton reset = new JButton("Reset");
        gbc.gridx = 0;
        gbc.gridy = 12;
        add(reset,gbc);
        reset.addActionListener(this);


        //questions array
        questionsArray = new String[]{"Bread Quiz", "1. What is the term for the process of allowing dough to rise before baking?", 
        "2. What gives sourdough bread its distinctive tangy flavor?","3. Which type of bread is typically braided before baking?",
        "4. What is the main ingredient in a French baguette?", "5. What is the purpose of kneading dough?", 
        "6. Which ingredient is essential for making bread rise?","7. What is the term for the process of cutting slits or patterns into the top of bread dough before baking?",
        "8. What is the term for the process of adding additional ingredients, such as dried fruits or nuts, to bread dough before baking?", 
        "9. What is the name for a type of Italian bread made with olive oil and herbs, often served as an appetizer?", 
        "10. Which type of bread is traditionally served during the Jewish Sabbath?"};

        //will display all of the questions in questionsArray
        showLabel(gbc);
 
      
        //set up display settings
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        pack();
        setSize(1150,650);
        setLocation(50,50);
        setVisible(true);
        


        //what happens when submit button is pressed
        submit.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                //checks for correct answers

                for (int i = 0; i < comboBoxes.length; i++) {
                    JComboBox<String> comboBox = comboBoxes[i];
                    String selectedItem = (String) comboBox.getSelectedItem();
                    System.out.println("ComboBox " + (i + 1) + " selected item: " + selectedItem);

                    if(selectedItem.contains(correct[i]))
                    {
                        correctAmt ++;
                    }
                }
                System.out.println("correct: " + correctAmt);
                
                
                
                //output the results on the screen
                tfResult.setText("Your score is: " + correctAmt+ "/10");
                correctAmt = 0;

            }
        });//end addActionListener submit

        menu.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                 setVisible(false);
                
            }
            
        });

        reset.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
               correctAmt = 0;
               for (JComboBox comboBox : comboBoxes) {
                comboBox.setSelectedIndex(0); // Reset to the first option
            }
            tfResult.setText("");
                
    
            //}

            }
            
        });
            
        
    }//end myButton method



    

    //method for displaying questions
    public void showLabel(GridBagConstraints GBC )
    {
        //parameters: array, position
        for (int i = 0; i < questionsArray.length; i++) {
            JLabel question = new JLabel(questionsArray[i]);
            GBC.gridx = 0;
            GBC.gridy = i;
            
            add(question, GBC);
        }
    }

 
    
   
    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
   
        JComboBox comboBox1 = (JComboBox) e.getSource();
        String userAnswer = (String)comboBox1.getSelectedItem();
        System.out.println(userAnswer);
    }





    public void BreadQuiz() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'BreadQuiz'");
    }


   
}//end AbbiesButton class
