/*
 * Vivian Sumbera
 * Gui Final Project
 * 4/18/24
 * UIN: 232006895
 * Section: 507
 */
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Hangman2 extends JPanel implements ActionListener {
    private String[] words = {"CUISINE", "COTTON CANDY", "STRAWBERRY", "HAMBURGER", "SWEET TREAT"};
    private String selectedWord;
    private char[] guessedLetters;
    private int wrongGuesses = 0;
    private String wrongLetters = "";
    private JLabel wrongLettersLabel;
    private boolean winner = false;
    private JButton endButton;
    private JFrame frame;

    public Hangman2(JFrame frame) {
        this.frame = frame;
        //setTitle("Hangman Game");
        //setDefaultCloseOperation(Jframe.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(600, 600));
        //setLocation(250, 50);
        setBackground(Color.WHITE);
        setFocusable(true);
        requestFocus();

        // Selects a random word
        int index = (int) (Math.random() * words.length);
        selectedWord = words[index];
        guessedLetters = new char[selectedWord.length()];

        //creates the dashes on the frame to represent the letters
        for (int i = 0; i < guessedLetters.length; i++) {
            if (selectedWord.charAt(i) == ' '){
                guessedLetters[i] = ' ';
            }
            else {
                guessedLetters[i] = '_';
            }
        }

        //creates the wrong letters label
        wrongLettersLabel = new JLabel("Wrong letters: ");
        wrongLettersLabel.setFont(new Font("Georgia", Font.PLAIN, 16));
        add(wrongLettersLabel);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = Character.toUpperCase(e.getKeyChar());
                if (Character.isLetter(c)) {
                    checkLetter(c);
                }
            }
        });
    }

            
    //checks to see if the guessed letter is in the work
    private void checkLetter(char letter) {
        boolean found = false;
        for (int i = 0; i < selectedWord.length(); i++) {
            if (selectedWord.charAt(i) == letter) {
                guessedLetters[i] = letter;
                found = true;
            }
        }
        if ((!found)&&(letter != ' ')) {
            wrongGuesses++;
            if(!wrongLetters.contains(Character.toString(letter))) {
                wrongLetters += letter + " ";
                wrongLettersLabel.setText("Wrong letters: " + wrongLetters);
            }
            //ends the game if the hangman is completed
            if(wrongLetters.length() >= 12) {
                winner = true;
                repaint();
                JOptionPane.showMessageDialog(this, "Game over! You didn't guess the word!");
                frame.dispose();
            }
        }
        //end the game if the word is guessed
        if(String.valueOf(guessedLetters).equals(selectedWord)) {
            winner = true;
            repaint();
            JOptionPane.showMessageDialog(this, "Congratulations! You guessed the word!");
            frame.dispose();
        }
        repaint();
    }

    //draws the hangman on the screen
    private void drawHangman(Graphics g) {
        int width = 150;
        int height = 200;

        // draws hangman platform
        g.drawLine(100, 500, 300, 500);
        g.drawLine(200, 500, 200, 100);
        g.drawLine(200, 100, 400, 100);
        g.drawLine(400, 100, 400, 150);

        //draws head
        if (wrongGuesses >= 1) {
            g.drawOval(375, 150, 50, 50);
        }
        //draws body
        if (wrongGuesses >= 2) {
            g.drawLine(400, 200, 400, 350);
        }
        //draws left arm
        if (wrongGuesses >= 3) {
            g.drawLine(400, 225, 350, 275);
        }
        //draws right arm
        if (wrongGuesses >= 4) {
            g.drawLine(400, 225, 450, 275);
        }
        //draws left leg
        if (wrongGuesses >= 5) {
            g.drawLine(400, 350, 350, 400);
        }
        //draws right leg
        if (wrongGuesses >= 6) {
            g.drawLine(400, 350, 450, 400);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Draw guessed word
        g.setColor(Color.BLACK);
        Font font = new Font("Georgia", Font.BOLD, 24);
        g.setFont(font);
        int x = 50;
        for (char c : guessedLetters) {
            if(c != ' ') {
                g.drawString(Character.toString(c), x, 50);
            }
            else {
                x += 30;
                continue;
            }
            x += 30;
        }
        // draws hangman
        drawHangman(g);
    }

    // public static void main(String[] args) {
    //     SwingUtilities.invokeLater(() -> {
    //         JFrame frame = new JFrame("Hangman Game");
    //         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //         frame.getContentPane().add(new Hangman2());
    //         frame.pack();
    //         frame.setLocationRelativeTo(null);
    //         frame.setVisible(true);
    //         //instructions
    //         JOptionPane.showMessageDialog(null, "Instructions: \nUse your keyboard to guess letters. \nIf you get a letter correct it will appear in the correct spot. \nIf you guess a letter wrong it will appear at the top of the screen and a part of the hangman is drawn. \nThe game is over if you guess the word correctly or if the hangman is complete. \nGoodluck!");

    //     });
    // }

    @Override
    public void actionPerformed(ActionEvent e) {
       
    }
}